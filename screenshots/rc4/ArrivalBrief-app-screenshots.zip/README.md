# Arrival Brief RC4 실제 앱 화면

버전: 1.0.0-rc4 / 정리일: 2026-11-02 KST

이 묶음은 서명된 RC4 release APK를 일반 Android 9 에뮬레이터에서 실행한 6개 화면입니다.
모든 원본은 가로 1280×800이며 원본 PNG 바이트를 유지했습니다.
PDF는 한 페이지에 한 화면을 온전한 비율로 배치하고 제목과 외곽 프레임만 추가했습니다.

- ArrivalBrief-app-screenshots.pdf: 실제 앱 화면 6쪽
- ArrivalBrief-app-screenshots-overview.png: 6장 모음
- originals/: 수정하지 않은 원본 PNG 6장
- presentation/: PDF의 각 페이지 PNG 6장
- manifest.json / screenshot-index.csv: 제목·글자 배율·원본 해시
- source-gallery-manifest.json / source-runtime-evidence.json: 검증 자료의 원본 사본

실제 Pleos 서비스·실차 촬영·실물 휴대폰 카메라 QR 판독을 확인한 자료는 아닙니다.
기본·확대 QR 화면은 같은 저장 메모와 저장 시각을 유지한 상태를 보여줍니다.
QR 판독 검토에는 축소된 모음 이미지가 아니라 originals/의 원본을 사용하세요.
RC3 연속 영상과 RC2 스크린샷은 이 RC4 묶음에 혼합하지 않았습니다.

출처: https://github.com/dbwls99706/arrival-brief/tree/main/screenshots/rc4
APK SHA-256: 865fb8368a81351575790fade68d5d27d805c1cfa8290897082fef056faa9da9
