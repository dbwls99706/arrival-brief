# 익명 검토 ZIP 구성

이 전달본은 업로드 용량을 줄이기 위해 동일한 파일의 중복만 정리했습니다. 앱 소스와 빌드 입력은 원본 바이트 그대로이며 모든 고유 캡처, 검증 결과와 30초 설명 영상 3편을 포함합니다.

- APK는 [dist/downloads/ArrivalBrief_release.apk](dist/downloads/ArrivalBrief_release.apk)에 한 번만 들어 있습니다. 정적 서버 루트는 기존대로 `dist`를 사용합니다.
- 178.357초 연속 원본 녹화는 전체 운영 ZIP의 `android-aosp28-rc1-ui-first180.mp4`와 별도 공개 저장소 파일로 보존했습니다. 이 익명 ZIP에는 원본의 경로·크기·해시와 시험 결과가 남아 있습니다.
- 문서의 APK 경로와 중복 캡처 참조는 아래 유지 경로로 조정했습니다. 앱 구현·APK·캡처 이미지 내용은 변경하지 않았습니다.

## 중복 정리 및 별도 제공 기록

- `apk/ArrivalBrief_release.apk` → `dist/downloads/ArrivalBrief_release.apk` · 6658807 bytes · SHA-256 `04114df0de41218e21b293609e6625983f4eb615d77ade959ec3bb2a8c48e8bf`
- `docs/verification/android-aosp28-a10b-confirmed.png` → `docs/verification/android-aosp28-a10b-confirmed-parked.png` · 104484 bytes · SHA-256 `e95d7c22dcc244b2c9de01f21247b2701698e52e3f5b49844f9b594049e513d6`
- `docs/verification/android-aosp28-a10b-qr.png` → `docs/verification/android-aosp28-a10b-saved-memo-qr.png` · 48796 bytes · SHA-256 `0e2588b982c1d1f23b27f636a15f16a74d75826669d638657f13af282180f535`
- `docs/verification/arrival-rc1-confirmed.jpg` → `docs/verification/arrival-rc1-confirmed-result.jpg` · 88773 bytes · SHA-256 `1617c757e70b497e44f59c960814dc7ebf9e536eb53299976095c8835e98078e`
- `docs/verification/android-aosp28-rc1-ui-first180.mp4` → `android-aosp28-rc1-ui-first180.mp4` · 3828953 bytes · SHA-256 `876a6f60a3e533348261f561702d7e6ba0838b09aca82a367d74735918a0faf1`
