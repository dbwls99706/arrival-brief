# Arrival Brief - 실제 Android 앱 스크린샷

## RC3 현재 화면

[RC3 실제 release 앱 화면 6장과 원본·검증 기록](rc3/README.md)을 먼저 확인하세요. 안내문 가져오기 → 도착 패스 확정 → 일정·등록 원문 → 주행 데모 잠금 → 주차 위치 저장 → QR까지 동일한 서명 release APK로 촬영했습니다.

[Arrival Brief RC3 실제 release 앱 화면 6장 (별도 보존 자료)](../PACKAGE-CONTENTS.md)

일반 Android 9 에뮬레이터의 가로 1280×800 화면입니다. 실제 Pleos·실차 촬영이나 실물 휴대폰 QR 스캔 성공을 뜻하지 않습니다.

## RC2 이전 기록

아래 PDF·ZIP·대표 PNG·원본 30장은 **이전 1.0.0-rc2 기록**입니다. 최초 배포 파일을 그대로 보존하며 현재 RC3 화면과 구분합니다.

버전: 1.0.0-rc2 / 정리일: 2026-11-02 KST

## 미리보기와 다운로드

[Arrival Brief 주요 앱 화면 6장 (별도 보존 자료)](../PACKAGE-CONTENTS.md)

- [전체 스크린샷 ZIP (별도 보존 자료)](../PACKAGE-CONTENTS.md)
- [대표 화면 8쪽 PDF (별도 보존 자료)](../PACKAGE-CONTENTS.md)
- [대표 화면 PNG 8장 (별도 보존 자료)](../PACKAGE-CONTENTS.md)
- [원본 PNG 30장 (별도 보존 자료)](../PACKAGE-CONTENTS.md)
- [원본 목록 CSV](screenshot-index.csv) · [출처와 SHA-256](manifest.json)

ZIP은 처음 배포한 스크린샷 패키지 그대로이며, 이 폴더의 README에는 GitHub에서 보기 편한 미리보기와 링크를 추가했습니다.

## 구성

- ArrivalBrief-app-screenshots-overview.png: 주요 흐름 6장을 한 장으로 정리
- ArrivalBrief-app-screenshots.pdf: 대표 8장을 한 페이지에 하나씩 수록
- presentation/: 제목과 가로형 기기 프레임을 붙인 대표 화면 8장
- originals/: 실제 앱 캡처 원본 PNG 30장, 원본 바이트 유지
- screenshot-index.csv / manifest.json: 원본 이름, 빌드 구분, 글자 크기, 해시와 출처

## 확인 범위

일반 Android 9 에뮬레이터의 실제 앱 화면입니다. 첫 실행과 설치된 아이콘은 release APK, 나머지는 같은 RC2 소스의 debug 자동 UI 시험 캡처입니다. 모두 가로 1280×800(16:10)이며, 화면 내용이나 상태를 합성·수정하지 않았습니다. 원본 외곽에만 제목·설명·기기 형태의 프레임을 배치했습니다. 웹 소개 화면이나 생성형 목업은 포함하지 않습니다.

실제 Pleos·실차 촬영 또는 실물 휴대폰 카메라 검증을 뜻하지 않습니다. 최종 QR 캡처의 독립 판독기 교차 검사는 3/4였고 OpenCV 미인식 1건이 기록되어 있습니다. 화면 모음의 축소 이미지 대신 originals/의 원본을 사용해 검토하세요.

원본 파일의 이름에 memo 또는 picker가 있어도 저장된 메모값이나 선택 대화상자가 모두 보이는 것은 아닙니다. 대표 주차 메모 화면에는 실제 키보드와 입력란이 보이는 ime 캡처를 선택했습니다.

출처: [운영용 저장소 주소 별도 전달]
